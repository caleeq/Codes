package com.ye.back.service;

import com.ye.back.entity.School;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author 何进业
 * @since 2021-06-10
 */
public interface SchoolService extends IService<School> {

}
