# education
基于springboot+shiro+Mybatis-Plus+Vue 实现的前后端分离简易教务系统，完全适合前后端分离开发初学者，以及shiro初学者。
shiro使用了自定义拦截器和自定义密码验证器。
数据库中多处使用了触发器。
